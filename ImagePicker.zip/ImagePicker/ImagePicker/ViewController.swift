//
//  ViewController.swift
//  ImagePicker
//
//  Created by Mac on 7/24/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    let imagepick = UIImagePickerController()
    
    var fileManagaer:FileManager?
    var documentDir:NSString?
    var filePath:NSString?
    
  
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblOpen: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagepick.delegate = self
        
        let dirPaths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        documentDir = dirPaths as NSString
        print("path : \(documentDir)")
       
    }

    @IBAction func btnActionOpen(_ sender: UIButton)
    {
    
        
        
        let alert = UIAlertController(title: nil,
                                      message: nil,
                                      preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Open Camera",
                                      style: .default,
                                      handler: { (action) in
                                        
                                        self.openCamera()
            
        }))
        alert.addAction(UIAlertAction(title: "Open Gallary",
                                      style: .cancel,
                                      handler: { (action) in
                                        self.openGallary()
            
        }))
        
        present(alert, animated: true, completion: nil)
    }
    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            imagepick.sourceType = UIImagePickerControllerSourceType.camera
            imagepick.allowsEditing = true
            self.present(imagepick, animated: true, completion: nil)
        }
        
    }
    func openGallary()
    {
        imagepick.sourceType = UIImagePickerControllerSourceType.photoLibrary
        imagepick.allowsEditing = true
        self.present(imagepick, animated: true, completion: nil)
    }
   
    @IBAction func btnDownload(_ sender: UIButton)
    {
        
        let documentsDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
     
        
        let fileURL = documentsDirectoryURL.appendingPathComponent("saveimage.jpg")
        
        
        if !FileManager.default.fileExists(atPath: fileURL.path) {
            do {
                try UIImagePNGRepresentation(imgView.image!)!.write(to: fileURL)
                print("Image Added Successfully")
            } catch {
                print(error)
            }
        } else {
            print("Image Not Added")
        }
        
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        if let ChooseImage = info[UIImagePickerControllerOriginalImage] as? UIImage
        {
            imgView.contentMode = .scaleAspectFit
            imgView.image = ChooseImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
        picker.dismiss(animated: true, completion: nil)
    }
}

